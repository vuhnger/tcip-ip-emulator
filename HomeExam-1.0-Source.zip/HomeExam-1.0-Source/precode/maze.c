#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "maze.h"

void mazeSolve( struct Maze* maze )
{
    fprintf( stderr, "%s has not been implemented yet\n", __FUNCTION__ );
}

